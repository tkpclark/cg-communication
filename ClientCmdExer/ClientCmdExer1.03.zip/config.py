#encoding:utf-8
terminal_number = 'T55-007'
community_id = '14'
server_ip = '115.28.134.72'
server_port = 9999
ftp_server = '115.28.134.72'
ftp_port = '21'
ftp_username = 'tkp'
ftp_password = 'ff'
ftp_upload_path = 'snapshot'
local_snapshot = './snapshot'
bandwidth_url = 'http://112.124.98.113/metrojs.js'#测试带宽时用来下载的文件
version = '1.03'